export type LeapWebhookImage = {
  uri: string;
}